package collagefiles.Controller;

public interface CollageController {


  void runProgram() throws IllegalStateException;

}

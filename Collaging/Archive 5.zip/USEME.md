USE ME

- First either click New Project or Load Project (no other functionality works until you do)

  -If New Project is selected, please specify the width and height (both must be the same number)
    - A new canvas will be created and you can now add layers.

        - If Load Project is selected, please select a .txt file that contains the format of the
          project.
            - all your layers, images, and filters will be loaded in


- Add layer will prompt you to enter the layer’s name. You cannot place images until you have
  created at least one layer, so please do this first. Nor can you apply filters til you have at
  least 1 layer created

- Add image will prompt you to firstly select an image (must be a .ppm P3) from your computer.
    - Then you will have to offset the image by the desired amount (must be > 0)
    - Then select the layer you want to add the image to

- Apply filter will first ask you which type of filter you would like to apply. Then, it will ask
  which layer you will apply it to. You can select the layer and apply the filter BEFORE OR AFTER
  you add images to the layer. it doesn’t matter when the image is added, the relevant filter will
  be applied

- Save Image will prompt you to name the image, and then please select a folder that you will save
  the image to. dont click inside the folder just click the icon in the navigator

- Save Project will prompt you to name the project, and then please
  select a folder that you will save the project to. dont click inside the folder just click the
  icon in the navigator